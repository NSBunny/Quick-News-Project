from django.shortcuts import render
import requests
from bs4 import BeautifulSoup

# GEtting news from Times of India

toi_r = requests.get("https://timesofindia.indiatimes.com/briefs")
toi_soup = BeautifulSoup(toi_r.content, 'html5lib')

toi_headings = toi_soup.find_all('h2')

toi_headings = toi_headings[0:-13] # removing footers

toi_news = []

for th in toi_headings:
    toi_news.append(th.text)



#Getting news from Hindustan times

ie_r = requests.get("https://indianexpress.com/section/india/")
ie_soup = BeautifulSoup(ie_r.content, 'html5lib')
ie_headings = ie_soup.find_all('h2')

ie_headings = ie_headings[0:-13] # removing footers

ie_news = []

for tie in ie_headings:
    ie_news.append(tie.text)


def index(req):
    return render(req, 'news/index.html', {'toi_news':toi_news, 'ht_news': ie_news})